<?php
// Include the database connection file
include "db_conn.php";

// Check if id is set in URL
if (isset($_GET['id']) && !empty(trim($_GET['id']))) {
    $id = $_GET['id'];

    // SQL query to delete the record
    $sql = "DELETE FROM `student` WHERE id = '$id'";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Successful deletion, redirect back to index.php
        header("location: index.php?status=deleted");
        exit();
    } else {
        // Failed deletion, redirect with an error status
        header("location: index.php?status=delete_failed");
        exit();
    }
} else {
    // ID parameter not found or is empty, redirect to index.php
    header("location: index.php?status=no_id");
    exit();
}

// Close the connection (though exit() handles this, it's good practice)
mysqli_close($conn);
?>
