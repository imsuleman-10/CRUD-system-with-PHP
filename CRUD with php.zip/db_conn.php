<?php
/**
 * Database Connection Configuration
 *
 * NOTE: Please update the constants below with your actual database credentials.
 * The 'crud_app' database name is assumed based on the table structure.
 */

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', ''); // Use your MySQL password (often empty for local XAMPP/WAMP)
define('DB_NAME', 'crud_app'); // IMPORTANT: Ensure this database exists

// Attempt to connect to MySQL database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect to the database. " . mysqli_connect_error());
}
?>
