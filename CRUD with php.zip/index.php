<?php
// Include the database connection file
include "db_conn.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD Application</title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles for better readability and centering */
        body { font-family: 'Inter', sans-serif; background-color: #f4f7f9; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        table { border-collapse: separate; border-spacing: 0; width: 100%; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1); border-radius: 0.5rem; overflow: hidden; }
        th, td { padding: 12px 15px; text-align: left; }
        th { background-color: #3b82f6; color: white; font-weight: 600; text-transform: uppercase; }
        tr:nth-child(even) { background-color: #eef2ff; } /* Light blue-ish stripe */
        tr:nth-child(odd) { background-color: #ffffff; }
        tr:hover td { background-color: #dbeafe; }
        .btn-edit { background-color: #22c55e; color: white; padding: 6px 12px; border-radius: 0.25rem; font-weight: 500; }
        .btn-delete { background-color: #ef4444; color: white; padding: 6px 12px; border-radius: 0.25rem; font-weight: 500; }
        .btn-add { background-color: #10b981; color: white; padding: 10px 20px; border-radius: 0.5rem; font-weight: 600; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-4xl font-extrabold text-gray-800 mb-8 text-center">Student Record Management</h1>

        <!-- Add New Button -->
        <div class="mb-4 text-right">
            <a href="add.php" class="btn-add hover:bg-emerald-600 transition duration-150 ease-in-out">Add New Student</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Roll num</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // SQL query to select all records from the 'student' table
                $sql = "SELECT * FROM `student`";

                // Execute the query
                $result = mysqli_query($conn, $sql);

                // Check if any rows were returned
                if (mysqli_num_rows($result) > 0) {
                    // Loop through the results and display them in table rows
                    while ($row = mysqli_fetch_assoc($result)) {
                ?>
                        <tr>
                            <td><?php echo $row["id"]; ?></td>
                            <td><?php echo $row["fname"]; ?></td>
                            <td><?php echo $row["lname"]; ?></td>
                            <td><?php echo $row["email"]; ?></td>
                            <td><?php echo $row["rollno"]; ?></td>
                            <td>
                                <!-- Edit Button -->
                                <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn-edit hover:bg-green-600 transition duration-150 ease-in-out">Edit</a>
                                <!-- Delete Button -->
                                <a href="delete.php?id=<?php echo $row['id']; ?>" 
                                   class="btn-delete hover:bg-red-600 transition duration-150 ease-in-out" 
                                   onclick="return confirm('Are you sure you want to delete this record?');">
                                   Delete
                                </a>
                            </td>
                        </tr>
                <?php
                    } // end while loop
                } else {
                    // Display a message if no records are found
                    echo '<tr><td colspan="6" class="text-center py-4 text-gray-500">No records found. Click "Add New Student" to create one.</td></tr>';
                }
                // Free result set
                mysqli_free_result($result);

                // Close the connection
                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
