<?php
// Include the database connection file
include "db_conn.php";

$error_message = "";

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data and sanitize it (Basic sanitation)
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $rollno = mysqli_real_escape_string($conn, $_POST['rollno']);

    // Validate form fields (simple check)
    if (empty($fname) || empty($lname) || empty($email) || empty($rollno)) {
        $error_message = "All fields are required.";
    } else {
        // Prepare the insert statement
        $sql = "INSERT INTO `student` (fname, lname, email, rollno) VALUES ('$fname', '$lname', '$email', '$rollno')";

        // Execute the statement
        if (mysqli_query($conn, $sql)) {
            // Success! Redirect to the main page
            header("location: index.php?status=added");
            exit();
        } else {
            $error_message = "ERROR: Could not execute query: " . mysqli_error($conn);
        }
    }
}

// Close the connection
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Student</title>
    <!-- Load Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f4f7f9; }
        .card { max-width: 500px; margin: 50px auto; padding: 30px; background-color: white; border-radius: 1rem; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1); }
        input[type="text"], input[type="email"] { width: 100%; padding: 10px; border: 1px solid #d1d5db; border-radius: 0.5rem; margin-top: 4px; }
        .btn-primary { background-color: #3b82f6; color: white; padding: 10px 20px; border-radius: 0.5rem; font-weight: 600; }
        .btn-secondary { background-color: #6b7280; color: white; padding: 10px 20px; border-radius: 0.5rem; font-weight: 600; }
    </style>
</head>
<body>
    <div class="card">
        <h1 class="text-3xl font-bold text-gray-800 mb-6 text-center">Add New Student Record</h1>
        <?php if (!empty($error_message)): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold">Error!</strong>
                <span class="block sm:inline"><?php echo $error_message; ?></span>
            </div>
        <?php endif; ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="space-y-4">
            <div>
                <label for="fname" class="block text-sm font-medium text-gray-700">First Name:</label>
                <input type="text" id="fname" name="fname" required>
            </div>
            <div>
                <label for="lname" class="block text-sm font-medium text-gray-700">Last Name:</label>
                <input type="text" id="lname" name="lname" required>
            </div>
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div>
                <label for="rollno" class="block text-sm font-medium text-gray-700">Roll Number:</label>
                <input type="text" id="rollno" name="rollno" required>
            </div>
            <div class="flex justify-between pt-4">
                <button type="submit" class="btn-primary hover:bg-blue-600 transition duration-150 ease-in-out">Submit</button>
                <a href="index.php" class="btn-secondary hover:bg-gray-600 transition duration-150 ease-in-out">Cancel</a>
            </div>
        </form>
    </div>
</body>
</html>
