CREATE DATABASE crud_app;
USE crud_app;

-- 2. Create the 'student' table
CREATE TABLE student (
    id INT(11) NOT NULL AUTO_INCREMENT,
    fname VARCHAR(50) NOT NULL,
    lname VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL,
    rollno VARCHAR(20) NOT NULL,
    PRIMARY KEY (id)
);